document.addEventListener("keyup", e=>{

  if (e.target.matches("#buscador")){

      if (e.key ==="Escape")e.target.value = ""

      document.querySelectorAll(".articulo").forEach(fruta =>{

          fruta.textContent.toLowerCase().includes(e.target.value.toLowerCase())
            ?fruta.classList.remove("filtro")
            :fruta.classList.add("filtro")
      })

  }

})
let hideText_btn=document.getElemtaryBId('hideText_btn');
let hideText=getElementById('hideText');
hideText_btn.addEventListener('click', toggleText);

function toggleText(){
hideText=classList.toggle('Show');
}